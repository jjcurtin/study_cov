#!/bin/bash
# cov.sh

#run R script, passing in args
Rscript fit_cov.R $1 $2 $3 $4 $5 $6 $7 $8