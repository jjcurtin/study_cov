#!/bin/bash
# execute.sh

#run R script, passing in args
Rscript fit_chtc.R $1 $2 $3